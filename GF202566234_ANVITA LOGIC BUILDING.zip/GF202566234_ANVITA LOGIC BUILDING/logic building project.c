// Online C compiler to run C program online
#include <stdio.h>
#include <string.h>

#define MAX_TRANS 100

struct Transaction {
    char type[20];
    int amount;
};

int balance = 5000;   // initial balance
int pin = 1234;       // default PIN
int transCount = 0;

struct Transaction history[MAX_TRANS];

// Function prototypes
int login();
void menu();
void checkBalance();
void withdraw();
void deposit();
void miniStatement();
void changePin();
void addTransaction(char type[], int amount);

int main() {
    printf("========================================\n");
    printf("           ATM MACHINE SYSTEM\n");
    printf("========================================\n");

    if (!login()) {
        printf("\nAccount locked! Too many wrong attempts.\n");
        return 0;
    }

    menu();
    return 0;
}

int login() {
    int userPin, attempts = 0;

    while (attempts < 3) {
        printf("\nEnter ATM PIN: ");
        scanf("%d", &userPin);

        if (userPin == pin) {
            printf("\nLogin Successful!\n");
            return 1;
        } else {
            printf("Incorrect PIN! Try again.\n");
            attempts++;
        }
    }
    return 0;  // lock account
}

void menu() {
    int choice;

    while (1) {
        printf("\n========================================\n");
        printf("               MAIN MENU\n");
        printf("========================================\n");
        printf("1. Check Balance\n");
        printf("2. Withdraw Money\n");
        printf("3. Deposit Money\n");
        printf("4. Mini Statement\n");
        printf("5. Change PIN\n");
        printf("6. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1: checkBalance(); break;
            case 2: withdraw(); break;
            case 3: deposit(); break;
            case 4: miniStatement(); break;
            case 5: changePin(); break;
            case 6:
                printf("\nThank you for using the ATM!\n");
                return;
            default:
                printf("Invalid choice! Please try again.\n");
        }
    }
}

void checkBalance() {
    printf("\n----------------------------------------\n");
    printf("             BALANCE INQUIRY\n");
    printf("----------------------------------------\n");
    printf("Available Balance: ₹%d\n", balance);
    printf("----------------------------------------\n");
}

void withdraw() {
    int amount;

    printf("\n----------------------------------------\n");
    printf("               WITHDRAWAL\n");
    printf("----------------------------------------\n");
    printf("Enter amount to withdraw: ");
    scanf("%d", &amount);

    if (amount <= 0 || amount % 100 != 0) {
        printf("Enter amount in multiples of 100.\n");
        return;
    }

    if (amount > balance) {
        printf("Insufficient balance!\n");
        return;
    }

    balance -= amount;
    addTransaction("Withdraw", amount);

    printf("Withdrawal successful!\n");
    printf("Remaining Balance: ₹%d\n", balance);
}

void deposit() {
    int amount;

    printf("\n----------------------------------------\n");
    printf("                 DEPOSIT\n");
    printf("----------------------------------------\n");
    printf("Enter amount to deposit: ");
    scanf("%d", &amount);

    if (amount <= 0) {
        printf("Invalid amount!\n");
        return;
    }

    balance += amount;
    addTransaction("Deposit", amount);

    printf("Deposit successful!\n");
    printf("Updated Balance: ₹%d\n", balance);
}

void miniStatement() {
    printf("\n----------------------------------------\n");
    printf("               MINI STATEMENT\n");
    printf("----------------------------------------\n");

    if (transCount == 0) {
        printf("No transactions yet.\n");
        return;
    }

    for (int i = 0; i < transCount; i++) {
        printf("%d. %s  ₹%d\n", i + 1, history[i].type, history[i].amount);
    }
    printf("----------------------------------------\n");
}

void changePin() {
    int oldPin, newPin;

    printf("\n----------------------------------------\n");
    printf("                CHANGE PIN\n");
    printf("----------------------------------------\n");

    printf("Enter current PIN: ");
    scanf("%d", &oldPin);

    if (oldPin != pin) {
        printf("Incorrect current PIN!\n");
        return;
    }

    printf("Enter new PIN: ");
    scanf("%d", &newPin);

    if (newPin < 1000 || newPin > 9999) {
        printf("PIN must be a 4-digit number.\n");
        return;
    }

    pin = newPin;
    printf("PIN changed successfully!\n");
}

void addTransaction(char type[], int amount) {
    if (transCount >= MAX_TRANS) return;
    strcpy(history[transCount].type, type);
    history[transCount].amount = amount;
    transCount++;
}