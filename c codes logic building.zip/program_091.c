#include <stdio.h>

// Program 91: Auto-generated sample C program
// This program simply prints its own program number.
int main() {
    printf("This is sample C program number 91.\n");
    return 0;
}
