#include <stdio.h>

// Program 110: Auto-generated sample C program
// This program simply prints its own program number.
int main() {
    printf("This is sample C program number 110.\n");
    return 0;
}
