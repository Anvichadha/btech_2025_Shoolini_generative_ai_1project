#include <stdio.h>

// Program 10: Auto-generated sample C program
// This program simply prints its own program number.
int main() {
    printf("This is sample C program number 10.\n");
    return 0;
}
