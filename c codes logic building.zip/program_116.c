#include <stdio.h>

// Program 116: Auto-generated sample C program
// This program simply prints its own program number.
int main() {
    printf("This is sample C program number 116.\n");
    return 0;
}
