#include <stdio.h>

// Program 217: Auto-generated sample C program
// This program simply prints its own program number.
int main() {
    printf("This is sample C program number 217.\n");
    return 0;
}
