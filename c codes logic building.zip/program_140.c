#include <stdio.h>

// Program 140: Auto-generated sample C program
// This program simply prints its own program number.
int main() {
    printf("This is sample C program number 140.\n");
    return 0;
}
