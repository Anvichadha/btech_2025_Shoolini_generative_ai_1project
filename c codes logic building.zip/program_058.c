#include <stdio.h>

// Program 58: Auto-generated sample C program
// This program simply prints its own program number.
int main() {
    printf("This is sample C program number 58.\n");
    return 0;
}
