#include <stdio.h>

// Program 205: Auto-generated sample C program
// This program simply prints its own program number.
int main() {
    printf("This is sample C program number 205.\n");
    return 0;
}
