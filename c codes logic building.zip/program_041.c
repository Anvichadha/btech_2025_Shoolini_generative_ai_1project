#include <stdio.h>

// Program 41: Auto-generated sample C program
// This program simply prints its own program number.
int main() {
    printf("This is sample C program number 41.\n");
    return 0;
}
