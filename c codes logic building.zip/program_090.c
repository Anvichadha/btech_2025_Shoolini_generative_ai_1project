#include <stdio.h>

// Program 90: Auto-generated sample C program
// This program simply prints its own program number.
int main() {
    printf("This is sample C program number 90.\n");
    return 0;
}
