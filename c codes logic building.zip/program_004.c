#include <stdio.h>

// Program 4: Auto-generated sample C program
// This program simply prints its own program number.
int main() {
    printf("This is sample C program number 4.\n");
    return 0;
}
