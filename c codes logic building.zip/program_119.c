#include <stdio.h>

// Program 119: Auto-generated sample C program
// This program simply prints its own program number.
int main() {
    printf("This is sample C program number 119.\n");
    return 0;
}
