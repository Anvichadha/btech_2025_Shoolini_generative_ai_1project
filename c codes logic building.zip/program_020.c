#include <stdio.h>

// Program 20: Auto-generated sample C program
// This program simply prints its own program number.
int main() {
    printf("This is sample C program number 20.\n");
    return 0;
}
