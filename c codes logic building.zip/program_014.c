#include <stdio.h>

// Program 14: Auto-generated sample C program
// This program simply prints its own program number.
int main() {
    printf("This is sample C program number 14.\n");
    return 0;
}
