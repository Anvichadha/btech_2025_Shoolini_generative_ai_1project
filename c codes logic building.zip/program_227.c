#include <stdio.h>

// Program 227: Auto-generated sample C program
// This program simply prints its own program number.
int main() {
    printf("This is sample C program number 227.\n");
    return 0;
}
