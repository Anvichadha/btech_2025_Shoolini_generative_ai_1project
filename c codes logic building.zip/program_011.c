#include <stdio.h>

// Program 11: Auto-generated sample C program
// This program simply prints its own program number.
int main() {
    printf("This is sample C program number 11.\n");
    return 0;
}
