#include <stdio.h>

// Program 191: Auto-generated sample C program
// This program simply prints its own program number.
int main() {
    printf("This is sample C program number 191.\n");
    return 0;
}
