#include <stdio.h>

// Program 149: Auto-generated sample C program
// This program simply prints its own program number.
int main() {
    printf("This is sample C program number 149.\n");
    return 0;
}
