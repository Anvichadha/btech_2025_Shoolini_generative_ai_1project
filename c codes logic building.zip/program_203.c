#include <stdio.h>

// Program 203: Auto-generated sample C program
// This program simply prints its own program number.
int main() {
    printf("This is sample C program number 203.\n");
    return 0;
}
