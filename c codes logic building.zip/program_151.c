#include <stdio.h>

// Program 151: Auto-generated sample C program
// This program simply prints its own program number.
int main() {
    printf("This is sample C program number 151.\n");
    return 0;
}
