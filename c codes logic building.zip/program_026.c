#include <stdio.h>

// Program 26: Auto-generated sample C program
// This program simply prints its own program number.
int main() {
    printf("This is sample C program number 26.\n");
    return 0;
}
