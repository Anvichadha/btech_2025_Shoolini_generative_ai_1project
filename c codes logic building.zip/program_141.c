#include <stdio.h>

// Program 141: Auto-generated sample C program
// This program simply prints its own program number.
int main() {
    printf("This is sample C program number 141.\n");
    return 0;
}
