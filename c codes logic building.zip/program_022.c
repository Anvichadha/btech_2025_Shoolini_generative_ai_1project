#include <stdio.h>

// Program 22: Auto-generated sample C program
// This program simply prints its own program number.
int main() {
    printf("This is sample C program number 22.\n");
    return 0;
}
