#include <stdio.h>

// Program 5: Auto-generated sample C program
// This program simply prints its own program number.
int main() {
    printf("This is sample C program number 5.\n");
    return 0;
}
