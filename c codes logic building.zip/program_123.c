#include <stdio.h>

// Program 123: Auto-generated sample C program
// This program simply prints its own program number.
int main() {
    printf("This is sample C program number 123.\n");
    return 0;
}
