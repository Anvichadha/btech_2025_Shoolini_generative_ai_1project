#include <stdio.h>

// Program 83: Auto-generated sample C program
// This program simply prints its own program number.
int main() {
    printf("This is sample C program number 83.\n");
    return 0;
}
