#include <stdio.h>

// Program 106: Auto-generated sample C program
// This program simply prints its own program number.
int main() {
    printf("This is sample C program number 106.\n");
    return 0;
}
