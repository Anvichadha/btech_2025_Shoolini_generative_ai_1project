#include <stdio.h>

// Program 173: Auto-generated sample C program
// This program simply prints its own program number.
int main() {
    printf("This is sample C program number 173.\n");
    return 0;
}
